from mensajes.hola.saludos import * 
from mensajes.adios.despedidas import *
saludar()
despedir()
Despedida()

