def saludar():
    print("Hola, te saludo desde saludos.saludar()")